
#ifndef M_LIBRARY_H
#define M_LIBRARY_H

#include <mgba-util/common.h>

CXX_GUARD_START

#ifdef ENABLE_VFS

#include <mgba/core/core.h>
#include <mgba-util/vector.h>

#define M_LIBRARY_MODEL_UNKNOWN -1

struct mLibraryEntry {
	const char* base;
	const char* filename;
	const char* title;
	char internalTitle[17];
	char internalCode[9];
	enum mPlatform platform;
	size_t filesize;
	uint32_t crc32;
	uint8_t md5[16];
	uint8_t sha1[20];
	int platformModels;
};

#ifdef USE_SQLITE3

DECLARE_VECTOR(mLibraryListing, struct mLibraryEntry);

struct mLibrary;
struct mLibrary* mLibraryCreateEmpty(void);
struct mLibrary* mLibraryLoad(const char* filename);
void mLibraryDestroy(struct mLibrary*);

struct VDir;
struct VFile;
void mLibraryLoadDirectory(struct mLibrary* library, const char* base, bool recursive);
void mLibraryClear(struct mLibrary* library);

size_t mLibraryCount(struct mLibrary* library, const struct mLibraryEntry* constraints);
size_t mLibraryGetEntries(struct mLibrary* library, struct mLibraryListing* out, size_t numEntries, size_t offset, const struct mLibraryEntry* constraints);
void mLibraryEntryFree(struct mLibraryEntry* entry);
struct VFile* mLibraryOpenVFile(struct mLibrary* library, const struct mLibraryEntry* entry);

struct NoIntroDB;
void mLibraryAttachGameDB(struct mLibrary* library, const struct NoIntroDB* db);

#endif

#endif

CXX_GUARD_END

#endif
